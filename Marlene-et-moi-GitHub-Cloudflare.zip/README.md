# Marlene et moi

Site statique prêt pour GitHub + Cloudflare Workers.

- Fichiers du site : `public/`
- Configuration Cloudflare : `wrangler.toml`
- Commande de déploiement : `npm run deploy`
