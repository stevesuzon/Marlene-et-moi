# Marlène et moi — version CLEAN v1
Reconstruction propre à partir de la version fonctionnelle fournie par l'utilisateur.
- pas d'écran de chargement bloquant
- catégories, panier, quantités, commande mail
- animation fil de laine petit panier -> grand panier
- 3 photos par article
- ajout/modification/suppression en mode admin
- John / Marlène + changement de code local
- PWA iPhone / téléphone / tablette / écran large
