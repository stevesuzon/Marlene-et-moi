const CACHE='marlene-et-moi-v16';
const CORE=['/manifest.webmanifest','/apple-touch-icon.png','/icon-192.png','/icon-512.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).catch(()=>{}).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('marlene-et-moi-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  const url=new URL(event.request.url);
  if(event.request.mode==='navigate' || url.pathname.endsWith('/index.html') || url.pathname==='/'){
    event.respondWith(fetch(event.request,{cache:'no-store'}).catch(()=>caches.match('/index.html')));
    return;
  }
  event.respondWith(fetch(event.request).then(resp=>{
    const copy=resp.clone();
    caches.open(CACHE).then(c=>c.put(event.request,copy)).catch(()=>{});
    return resp;
  }).catch(()=>caches.match(event.request)));
});
